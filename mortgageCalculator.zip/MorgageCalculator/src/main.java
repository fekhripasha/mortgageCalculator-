import java.text.NumberFormat;
import java.util.Scanner;

public class main {


    public static void  main(String []arg )
    {
        System.out.println("Enter amount of loan: ");
        Scanner scanner = new Scanner(System.in);
        int AmountOfLoan = scanner.nextInt();

        System.out.println("Enter annual interst rate: ");
        float AnnualInterestRate = scanner.nextInt();

        float MonthlyinterestRate = AnnualInterestRate/100/12;

        System.out.println("Enter mortage period in year: ");
        int  Year = scanner.nextInt();
        int PeriodInYear = Year*12;

        System.out.println("Enter number of payment: ");
        int NumberOfPayment = scanner.nextInt();
        double mortgage = AmountOfLoan
                * (MonthlyinterestRate * Math.pow(1 + MonthlyinterestRate, NumberOfPayment))
                / (Math.pow(1 + MonthlyinterestRate, NumberOfPayment) - 1);

        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Mortgage: " + mortgageFormatted);
    }
}
